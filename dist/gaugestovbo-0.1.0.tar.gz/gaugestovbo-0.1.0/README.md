# gaugesToVbo

A tool to convert gauge data to VBO format.

## Installation

You can install the package using pip:

pip install gaugesToVbo

## Usage

To use the tool, run:

gaugesToVbo input.csv output.vbo